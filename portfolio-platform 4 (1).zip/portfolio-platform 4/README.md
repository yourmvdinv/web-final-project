# Portfolio Platform

A web application that allows users to register, log in, and manage their portfolio items securely using Two-Factor Authentication (2FA).

## Features

- **User Authentication**: Registration, login, and logout functionality.
- **Two-Factor Authentication (2FA)**: 2FA via email to enhance security during login.
- **User Roles**: Admin, Editor, and User with different permissions.
- **Portfolio Management**: Users can create, update, and delete portfolio items.
- **NASA APOD Integration**: Fetch and display daily images from the NASA APOD API.
- **News and Crypto Visualization**: News fetching from RSS feeds and cryptocurrency data visualization using Chart.js.

## Setup Instructions

### Prerequisites

- **Node.js** (v14 or higher)
- **MongoDB** (local or cloud-based, such as MongoDB Atlas)
- **NPM** 
- A valid email account for sending 2FA codes (e.g., Mail.ru or Gmail)

### Installation Steps

1. **Clone the repository**:
   ```bash
   git clone https://github.com/your-repository-url.git
   cd portfolio-platform
   ```

2. **Install dependencies**:
   ```bash
   npm install
   ```

3. **Create a `.env` file** in the project root directory and add the following variables:
   ```plaintext
   PORT=3000
   MONGODB_URI=your-mongodb-uri
   JWT_SECRET=your-jwt-secret
   EMAIL_USER=your-email@example.com
   EMAIL_PASS=your-email-password
   NASA_API_KEY=your-nasa-api-key
   ```

4. **Start the MongoDB server** (if running locally).

5. **Run the application**:
   ```bash
   npm start
   ```

6. **Open the application** in your browser at [http://localhost:3000](http://localhost:3000).

## API Details

### Authentication Routes

| Endpoint          | Method | Description                                      | Protected |
|-------------------|--------|--------------------------------------------------|-----------|
| `/register`       | POST   | User registration                                | No        |
| `/login`          | POST   | User login with 2FA                              | No        |
| `/logout`         | GET    | Logs out the user                                | Yes       |

### Portfolio Routes

| Endpoint             | Method | Description                                      | Protected |
|----------------------|--------|--------------------------------------------------|-----------|
| `/portfolio`         | GET    | Fetch all portfolio items                        | Yes       |
| `/portfolio/create`  | POST   | Create a new portfolio item                      | Yes       |
| `/portfolio/update/:id` | POST | Update an existing portfolio item                | Yes       |
| `/portfolio/delete/:id` | POST | Delete an existing portfolio item                | Yes       |

### NASA APOD Route

| Endpoint     | Method | Description                                      | Protected |
|--------------|--------|--------------------------------------------------|-----------|
| `/nasa/apod` | GET    | Fetch daily image and data from NASA APOD API    | No        |

## Design Rationale

1. **Authentication and Security**:
    - **JWT**: Used for secure session management.
    - **2FA**: Adds an additional layer of security to protect user accounts.

2. **Modular Design**:
    - Routes and middleware are separated into different files for better scalability and maintainability.
    - Role-based access control is implemented for enhanced security and user management.

3. **Integration**:
    - NASA APOD API, RSS feeds, and Coingecko API provide rich, dynamic content to enhance the user experience.

4. **User-Friendly Interface**:
    - Forms include clear validation, and error messages are user-friendly.
    - Dynamic front-end rendering using EJS templating.

## Two-Factor Authentication (2FA) Setup

1. **Trigger**:
    - During login, if the 2FA code is not provided, a new code is generated.

2. **Delivery**:
    - The code is sent to the user's registered email address.

3. **Expiration**:
    - The 2FA code is valid for 10 minutes.

4. **Validation**:
    - On subsequent login attempts, the provided code is validated against the stored code in the database.

5. **Code Flow**:
    - Generate a 6-digit code using `Math.random`.
    - Save it in the database with an expiration timestamp.
    - Validate the provided code against the stored code and expiration time.

## Additional Notes

- Ensure MongoDB is properly configured and running before starting the application.
- Use a secure email service with proper credentials for sending 2FA codes.
- Replace placeholders in the `.env` file with your actual credentials and API keys.
- Adjust role-based access in middleware if adding new features.

---
