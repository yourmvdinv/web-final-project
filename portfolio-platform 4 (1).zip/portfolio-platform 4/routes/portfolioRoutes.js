// routes/portfolioRoutes.js
const express = require('express');
const router = express.Router();
const PortfolioItem = require('../models/PortfolioItem');
const multer = require('multer');
const path = require('path');

// Настройка хранилища для изображений в папке 'public/images'
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'public/images'); // Папка для загрузки изображений
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname)); // Имя файла = текущее время + расширение
  }
});

const upload = multer({ storage });

// Страница портфолио (показываем все элементы)
router.get('/portfolio', async (req, res) => {
  try {
    const portfolioItems = await PortfolioItem.find();
    res.render('portfolio', { portfolioItems });
  } catch (err) {
    console.error('Error fetching portfolio items:', err);
    res.status(500).send('Error fetching portfolio items');
  }
});


// Страница создания элемента портфолио
router.get('/portfolio/new', (req, res) => {
  res.render('createPortfolioItem');
});

// Создание нового элемента портфолио с изображениями
router.post('/portfolio', upload.array('images', 3), async (req, res) => {
  const { title, description } = req.body;

  // Получаем пути к изображениям, которые были загружены
  const images = req.files.map(file => `/images/${file.filename}`);

  const newItem = new PortfolioItem({
    title,
    description,
    images, // Сохраняем массив путей к изображениям
  });

  try {
    await newItem.save();
    res.redirect('/portfolio');
  } catch (err) {
    res.status(500).send('Error saving portfolio item');
  }
});

// Страница редактирования элемента
router.get('/portfolio/edit/:id', async (req, res) => {
  const { id } = req.params;
  try {
    const item = await PortfolioItem.findById(id);
    if (!item) {
      return res.status(404).send('Item not found');
    }
    res.render('editPortfolioItem', { item });
  } catch (err) {
    res.status(500).send('Error fetching portfolio item');
  }
});

// Обновление элемента портфолио
router.post('/portfolio/edit/:id', upload.array('images', 3), async (req, res) => {
  const { id } = req.params;
  const { title, description } = req.body;

  try {
    const item = await PortfolioItem.findById(id);
    if (!item) {
      return res.status(404).send('Item not found');
    }

    item.title = title;
    item.description = description;

    // Если были загружены новые изображения, обновляем их
    if (req.files && req.files.length > 0) {
      item.images = req.files.map(file => `/images/${file.filename}`);
    }

    item.updatedAt = Date.now(); // Обновляем дату

    await item.save();
    res.redirect('/portfolio');
  } catch (err) {
    res.status(500).send('Error updating portfolio item');
  }
});

// Удаление элемента портфолио
router.get('/portfolio/delete/:id', async (req, res) => {
  const { id } = req.params;
  try {
    const item = await PortfolioItem.findById(id);
    if (!item) {
      return res.status(404).send('Item not found');
    }

    await item.remove();
    res.redirect('/portfolio');
  } catch (err) {
    res.status(500).send('Error deleting portfolio item');
  }
});

module.exports = router;
