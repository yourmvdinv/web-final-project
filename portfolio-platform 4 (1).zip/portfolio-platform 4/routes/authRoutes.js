const express = require('express');
const router = express.Router();
const User = require('../models/User');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const nodemailer = require('nodemailer');

// Email Transporter Configuration
const transporter = nodemailer.createTransport({
  host: 'smtp.mail.ru',
  port: 465,
  secure: true,
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
});

// Render Register Page
router.get('/register', (req, res) => {
  res.render('register');
});

// Handle User Registration
router.post('/register', async (req, res) => {
  const { username, password, firstName, lastName, email, gender, age, role } = req.body;

  if (!username || !password || !firstName || !lastName || !email || !gender || !age) {
    return res.status(400).send('All fields are required');
  }

  try {
    const hashedPassword = await bcrypt.hash(password, 10);

    const newUser = new User({
      username,
      password: hashedPassword,
      firstName,
      lastName,
      email,
      gender,
      age,
      role: role || 'user',
    });

    await newUser.save();
    res.status(201).send('User registered successfully!');
  } catch (error) {
    console.error('Registration Error:', error);
    res.status(500).send('Error during registration.');
  }
});

// Render Login Page
router.get('/login', (req, res) => {
  res.render('login');
});

// Handle User Login
router.post('/login', async (req, res) => {
  const { username, password, twoFactorCode } = req.body;

  try {
    const user = await User.findOne({ username });
    if (!user) return res.status(401).send('Invalid username or password');

    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) return res.status(401).send('Invalid username or password');

    if (!twoFactorCode) {
      user.twoFactorCode = Math.floor(100000 + Math.random() * 900000); // 6-digit code
      user.twoFactorCodeExpires = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes expiry
      await user.save();

      await transporter.sendMail({
        from: process.env.EMAIL_USER,
        to: user.email,
        subject: 'Your 2FA Code',
        text: `Your 2FA code is: ${user.twoFactorCode}`,
      });

      return res.status(200).send('2FA code sent to your email. Please enter it to log in.');
    }

    if (twoFactorCode !== user.twoFactorCode || new Date() > user.twoFactorCodeExpires) {
      return res.status(401).send('Invalid or expired 2FA code');
    }

    // Clear Two-Factor Code
    user.twoFactorCode = null;
    user.twoFactorCodeExpires = null;
    await user.save();

    const token = jwt.sign({ id: user._id, role: user.role }, process.env.JWT_SECRET, { expiresIn: '1h' });
    res.cookie('token', token, { httpOnly: true });

    res.redirect('/home');
  } catch (error) {
    console.error('Login Error:', error);
    res.status(500).send('Login failed. Please try again.');
  }
});

module.exports = router;
