/**const PortfolioItem = require("../models/PortfolioItem");

// Получить все элементы портфолио
const getPortfolioItems = async (req, res) => {
    try {
        const portfolioItems = await PortfolioItem.find({});
        res.render("portfolio", { PortfolioItems: portfolioItems }); // Рендерим страницу портфолио с элементами
    } catch (error) {
        console.error("Error fetching portfolio items:", error);
        res.status(500).send("Internal Server Error");
    }
};

// Создать новый элемент портфолио
const createPortfolioItem = async (req, res) => {
    const { title, description } = req.body;
    const images = req.files.map((file) => `/uploads/${file.filename}`);

    try {
        const newItem = new PortfolioItem({ title, description, images });
        await newItem.save();
        res.redirect("/portfolio");
    } catch (error) {
        console.error("Error creating portfolio item:", error);
        res.status(500).send("Failed to create portfolio item");
    }
};

// Получить элемент портфолио по ID
const getPortfolioItem = async (req, res) => {
    const { id } = req.params;

    try {
        const portfolioItem = await PortfolioItem.findById(id);
        if (!portfolioItem) {
            return res.status(404).send("Portfolio item not found");
        }
        res.status(200).json(portfolioItem);
    } catch (error) {
        console.error("Error fetching portfolio item:", error);
        res.status(500).send("Internal Server Error");
    }
};


const updatePortfolioItem = async (req, res) => {
    const { id } = req.params;
    const { title, description } = req.body;

    try {
        const updatedItem = await PortfolioItem.findByIdAndUpdate(
            id,
            { title, description },
            { new: true, runValidators: true }
        );

        if (req.files && req.files.length > 0) {
            updatedItem.images = req.files.map((file) => `/uploads/${file.filename}`);
        }

        await updatedItem.save();

        res.redirect("/portfolio");
    } catch (error) {
        console.error("Error updating portfolio item:", error);
        res.status(500).send("Failed to update portfolio item");
    }
};

// Удалить элемент портфолио
const deletePortfolioItem = async (req, res) => {
    const { id } = req.params;

    try {
        const deletedItem = await PortfolioItem.findByIdAndDelete(id);
        if (!deletedItem) {
            return res.status(404).send("Portfolio item not found");
        }
        res.redirect("/portfolio");
    } catch (error) {
        console.error("Error deleting portfolio item:", error);
        res.status(500).send("Failed to delete portfolio item");
    }
};

module.exports = {
    getPortfolioItems,
    createPortfolioItem,
    getPortfolioItem,
    updatePortfolioItem,
    deletePortfolioItem,
};**/
