require('dotenv').config();
const express = require('express');
const axios = require('axios');
const mongoose = require('mongoose');
const path = require('path');
const cookieParser = require('cookie-parser');
const bodyParser = require('body-parser');

const authRoutes = require('./routes/authRoutes');
const portfolioRoutes = require('./routes/portfolioRoutes');

const app = express();
const port = 3000;

const nasaApiKey = process.env.NASA_API_KEY;

mongoose
    .connect(process.env.MONGODB_URI)
    .then(() => console.log('MongoDB connected'))
    .catch((err) => console.error('MongoDB connection error:', err));

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.set('view engine', 'ejs');

app.use((req, res, next) => {
  console.log(`${req.method} ${req.url}`);
  next();
});

app.get('/', (req, res) => {
  const user = req.cookies.user || null;
  res.render('home', { user });
});

app.get('/logout', (req, res) => {
  res.clearCookie('user');
  res.redirect('/');
});

app.post('/login', (req, res) => {
  const user = { username: req.body.username, role: 'admin' };
  res.cookie('user', user);
  res.redirect('/');
});

app.get('/nasa/apod', async (req, res) => {
  const api_url = `https://api.nasa.gov/planetary/apod?api_key=${nasaApiKey}`;
  try {
    const response = await axios.get(api_url);
    const data = response.data;

    res.json({
      title: data.title,
      hdurl: data.hdurl,
      explanation: data.explanation,
    });
  } catch (err) {
    console.error('Error fetching NASA data:', err.message);
    res.status(500).send(`Failed to fetch data from NASA API: ${err.message}`);
  }
});

app.use('/', authRoutes);
app.use('/', portfolioRoutes);

app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).send('Something went wrong!');
});

app.listen(port, () => console.log(`Server is running on http://localhost:${port}`));
