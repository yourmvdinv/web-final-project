/**const jwt = require('jsonwebtoken');

// Middleware для проверки авторизации пользователя
const checkAuth = (req, res, next) => {
    const token = req.cookies.token; // Retrieve the JWT from cookies

    if (!token) {
        return res.redirect('/login'); // Redirect to login if no token
    }

    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        req.user = decoded; // Attach user data to the request
        next();
    } catch (error) {
        console.error('JWT Verification Error:', error);
        res.redirect('/login'); // Redirect if token is invalid
    }
};

// Middleware для проверки роли
const checkRole = (role) => {
  return (req, res, next) => {
    if (!req.user || req.user.role !== role) {
      return res.status(403).send('Forbidden: You do not have the required role');
    }
    next();  // Если роль подходит, переходим к следующему middleware или маршруту
  };
};


module.exports = { checkAuth, checkRole };**/
